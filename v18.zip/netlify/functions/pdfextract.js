import Busboy from 'busboy';
import pdf from 'pdf-parse';

export const config = {
  api: {
    bodyParser: false
  }
};

function readFileFromMultipart(event) {
  return new Promise((resolve, reject) => {
    const headers = event.headers || {};
    const bb = Busboy({ headers });
    let fileBuffers = [];
    let gotFile = false;

    bb.on('file', (name, file) => {
      gotFile = true;
      file.on('data', (data) => fileBuffers.push(data));
    });
    bb.on('error', reject);
    bb.on('finish', () => {
      if (!gotFile) return reject(new Error('No PDF file uploaded.'));
      resolve(Buffer.concat(fileBuffers));
    });

    const body = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64') : Buffer.from(event.body || '', 'utf8');
    bb.end(body);
  });
}

export async function handler(event) {
  try {
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Method not allowed' }) };
    }
    const buffer = await readFileFromMultipart(event);
    const parsed = await pdf(buffer);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: parsed.text || '' })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message })
    };
  }
}
