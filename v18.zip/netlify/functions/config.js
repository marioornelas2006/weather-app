export async function handler() {
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      key: process.env.CHECKWX_API_KEY || ""
    })
  };
}
