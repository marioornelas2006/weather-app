export async function handler(event) {
  try {
    const url = event.queryStringParameters?.url;
    if (!url) {
      return { statusCode: 400, body: "Missing url parameter" };
    }

    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { statusCode: res.status, body: text || "Failed to fetch chart" };
    }

    const arrayBuffer = await res.arrayBuffer();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": res.headers.get("content-type") || "image/gif",
        "Cache-Control": "public, max-age=300"
      },
      body: Buffer.from(arrayBuffer).toString("base64"),
      isBase64Encoded: true
    };
  } catch (e) {
    return {
      statusCode: 500,
      body: "Prog chart proxy error: " + e.message
    };
  }
}
