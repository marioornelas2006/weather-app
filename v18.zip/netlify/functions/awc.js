export async function handler(event) {
  try {
    const product = event.queryStringParameters?.product;
    if (!product || !['gairmet', 'sigmet', 'airsigmet', 'convective_sigmet', 'cwa', 'taf'].includes(product)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invalid product' })
      };
    }

    const tryUrls = [];
    if (product === 'sigmet') {
      tryUrls.push('https://aviationweather.gov/api/data/sigmet?format=geojson');
      tryUrls.push('https://aviationweather.gov/api/data/airsigmet?format=geojson');
    } else if (product === 'cwa') {
      tryUrls.push('https://aviationweather.gov/api/data/cwa?format=geojson');
    } else if (product === 'taf') {
      const ids = event.queryStringParameters?.ids || '';
      tryUrls.push(`https://aviationweather.gov/api/data/taf?ids=${encodeURIComponent(ids)}&format=json`);
    } else {
      tryUrls.push(`https://aviationweather.gov/api/data/${product}?format=geojson`);
    }

    let lastStatus = 500;
    let lastBody = '';
    for (const url of tryUrls) {
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      const body = await res.text();
      if (res.ok) {
        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'public, max-age=120'
          },
          body
        };
      }
      lastStatus = res.status;
      lastBody = body;
    }

    return {
      statusCode: lastStatus,
      headers: { 'Content-Type': 'text/plain' },
      body: lastBody || 'Upstream fetch failed'
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message })
    };
  }
}
