export async function handler(event) {
  try {
    const idsParam = event.queryStringParameters?.ids || "";
    const ids = idsParam.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
    if (!ids.length) {
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({})
      };
    }

    const url = "https://davidmegginson.github.io/ourairports-data/runways.csv";
    const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (!res.ok) {
      return { statusCode: res.status, body: `Failed to fetch runway data` };
    }
    const csv = await res.text();

    function parseCsvLine(line) {
      const out = [];
      let cur = "";
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
          if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
          else inQuotes = !inQuotes;
        } else if (ch === "," && !inQuotes) {
          out.push(cur); cur = "";
        } else {
          cur += ch;
        }
      }
      out.push(cur);
      return out;
    }

    const lines = csv.split(/\r?\n/).filter(Boolean);
    const headers = parseCsvLine(lines[0]);
    const idx = Object.fromEntries(headers.map((h, i) => [h, i]));
    const result = {};
    ids.forEach(id => result[id] = { runways: [] });

    for (let i = 1; i < lines.length; i++) {
      const row = parseCsvLine(lines[i]);
      const ident = (row[idx.airport_ident] || "").toUpperCase();
      if (!result[ident]) continue;
      const closed = (row[idx.closed] || "").toLowerCase() === "1" || (row[idx.closed] || "").toLowerCase() === "true";
      if (closed) continue;
      const leIdent = row[idx.le_ident] || "";
      const heIdent = row[idx.he_ident] || "";
      const leHeading = row[idx.le_heading_degT] || "";
      const heHeading = row[idx.he_heading_degT] || "";
      if (leIdent) result[ident].runways.push({ ident: leIdent, heading: leHeading ? parseFloat(leHeading) : null });
      if (heIdent) result[ident].runways.push({ ident: heIdent, heading: heHeading ? parseFloat(heHeading) : null });
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=86400" },
      body: JSON.stringify(result)
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: e.message })
    };
  }
}
