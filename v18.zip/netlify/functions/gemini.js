export async function handler(event) {
  try {
    const body = JSON.parse(event.body || "{}");
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: { message: "GEMINI_API_KEY is not configured." } })
      };
    }

    const payload = {
      ...body,
      generationConfig: {
        temperature: 0.2,
        ...(body.generationConfig || {})
      }
    };

    const attempts = [
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey,
      "https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=" + apiKey,
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey,
      "https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=" + apiKey
    ];

    let lastError = null;

    for (const url of attempts) {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }

      const hasCandidate = !!data?.candidates?.[0]?.content?.parts?.length;
      const blocked = !!data?.promptFeedback?.blockReason;
      if (res.ok && (hasCandidate || blocked)) {
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        };
      }

      lastError = {
        status: res.status,
        url,
        message: data?.error?.message || data?.raw || ("HTTP " + res.status)
      };
    }

    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        error: {
          message: lastError?.message || "Gemini request failed.",
          status: lastError?.status || 502,
          modelAttempted: lastError?.url || null
        }
      })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: { message: e.message } })
    };
  }
}
